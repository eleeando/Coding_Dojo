

function deletek(){
    var k= document.querySelector('#cookie');
    k.remove();
}
function alert1() {
    alert('Your Cart is Empty')
}

function change() {
    var e=document.querySelector("#secc1");
    e.src="./images/assets/succulents-2.jpg"
}
function change2() {
    var e=document.querySelector("#secc1");
    e.src="./images/assets/succulents-1.jpg"
}